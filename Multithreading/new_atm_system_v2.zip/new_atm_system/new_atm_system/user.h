#ifndef USER_ACCOUNT_H
#define USER_ACCOUNT_H

#include <iostream>
#include <string>
#include <mutex>

class User
{
private:
    std::string m_name;
    int m_balance;
    std::mutex m_user_lock;
    
public:
    User(std::string name, int balance);
    ~User();

    std::string getUserName();
    int         getUserBalance();
    void        setUserBalance(int new_balance);
};

#endif