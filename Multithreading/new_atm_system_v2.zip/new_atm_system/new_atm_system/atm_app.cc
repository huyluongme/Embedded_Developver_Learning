#include <thread>
#include "atm_app.h"
#include "atm_exceptions.h"
#include "shared_variable.h"

ATMApp::ATMApp() {}

ATMApp::~ATMApp() {
    delete m_atm_services;
    delete m_sem;
    // delete m_pool;
}

void ATMApp::start(int atm_balance, int max_users) {
    m_atm_services = new ATMService(atm_balance);
    m_sem = new Semaphore(max_users);

    // Make sure all relatie object is created;
    std::this_thread::sleep_for(std::chrono::seconds(1));
}

void ATMApp::checkATMBalanceFeature() {
    // std::lock_guard<std::mutex> lock(m_atm_lock);
    std::cout << "Balance of ATM: " << m_atm_services->checkATMBalanceService() << '\n';
}

void ATMApp::checkUserBalanceFeature(User* user) {
    // std::lock_guard<std::mutex> lock(m_atm_lock);
    printf(BOLD BLUE "[%s]" YELLOW "[CHECK BALANCE]" GREEN " Balance: %d\n" RESET,
     user->getUserName().c_str(), user->getUserBalance());
    
    // std::cout << "Balance of " << user->getUserName() << ": " << user->getUserBalance() << '\n';
}

void ATMApp::withdrawFeature(User* user, int amount) {
    // std::lock_guard<std::mutex> lock(m_atm_lock);
    try
    {
        m_atm_services->withdrawService(user, amount);
        // std::cout << user->getUserName() << ": Withdrawal of " << amount << " was successful. ";
        // std::cout << "Balance of " << user->getUserName() << " is: " << user->getUserBalance() << "\n";
        {
            // std::lock_guard<std::mutex> lock(g_cout_lock);
            printf(BOLD BLUE "[%s]" YELLOW "[WITHDRAW][AMOUNT: %d]" GREEN " Successful! New balance: %d\n" RESET,
            user->getUserName().c_str(), amount, user->getUserBalance());
        }
    }
    catch (const UserInsufficientFundsException& e) {
        // std::lock_guard<std::mutex> lock(g_cout_lock);
        printf(BOLD BLUE "[%s]" YELLOW "[WITHDRAW][AMOUNT: %d]" RED " Failed: %s\n" RESET,
         user->getUserName().c_str(), amount, e.what());
        // std::cerr << "Error: " << e.what() << std::endl;
    } catch (const ATMInsufficientFundsException& e) {
        // std::lock_guard<std::mutex> lock(g_cout_lock);
        printf(BOLD BLUE "[%s]" YELLOW "[WITHDRAW][AMOUNT: %d]" RED " Failed: %s\n" RESET,
         user->getUserName().c_str(), amount, e.what());
        // std::cerr << "Error: " << e.what() << std::endl;
    }
}

void ATMApp::depositFeature(User* user, int amount) {
    // std::lock_guard<std::mutex> lock(m_atm_lock);
    m_atm_services->depositService(user, amount);
    {
        // std::lock_guard<std::mutex> lock(g_cout_lock);
        printf(BOLD BLUE "[%s]" YELLOW "[DEPOSIT][AMOUNT: %d]" GREEN " Successful! New balance: %d\n" RESET,
        user->getUserName().c_str(), amount, user->getUserBalance());
    }
    // std::cout << user->getUserName() << ": Deposit of " << amount << " was successfull. ";
    // std::cout << "Balance of " << user->getUserName() << " is: " << user->getUserBalance() << "\n";
}


void ATMApp::useATM(User* user, ATMFeature feature, int amount) {
    printf("[%s] is waiting to use ATM.\n", user->getUserName().c_str());
    m_sem->wait();
    printf("[%s] is using ATM.\n", user->getUserName().c_str());
    if(feature == ATMFeature::CHECK_BALANCE)
        checkUserBalanceFeature(user);
    else if(feature == ATMFeature::WITHDRAW)
        withdrawFeature(user, amount);
    else
        depositFeature(user, amount);
    printf("[%s] is done using ATM.\n", user->getUserName().c_str());
    // printf(BOLD YELLOW "[NOTICE] Balance of ATM: %d\n" RESET, m_atm_services->checkATMBalanceService());
    m_sem->notify();
}

