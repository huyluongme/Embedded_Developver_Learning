#include "shared_variable.h"

int atm_balance = 10000;
int users_num = 20;
int max_users = 3;
int thread_num = 5;
int sleep_milisecond = 1000;
int task_num = 100;