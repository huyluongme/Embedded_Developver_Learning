#ifndef ATM_APP_H
#define ATM_APP_H

#include "atm_service.h"
#include "semaphore.h"

#define RESET "\033[0m"
#define BOLD "\033[1m"
#define RED "\033[91m"
#define GREEN "\033[92m"
#define YELLOW "\033[93m"
#define BLUE "\033[94m"

enum ATMFeature {
    CHECK_BALANCE,
    WITHDRAW,
    DIPOSIT,
};

class ATMApp
{
private:
    ATMService* m_atm_services;
    Semaphore* m_sem;
public:
    ATMApp();
    ~ATMApp();

    void start(int atm_balance, int max_users);
    void checkATMBalanceFeature();
    void checkUserBalanceFeature(User* user);
    void withdrawFeature(User* user, int amount);
    void depositFeature(User* user, int amount);
    void useATM(User* user, ATMFeature feature, int amount);

};

#endif