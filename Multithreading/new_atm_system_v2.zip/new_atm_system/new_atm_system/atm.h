#ifndef ATM_H
#define ATM_H

#include <mutex>

class ATM
{
private:
    int m_atm_balance;
    std::mutex m_atm_lock;
    
public:
    ATM(int atm_balance);
    ~ATM();

    int     getATMBalance();
    void    setATMBalance(int new_balance);
    // void withdrawFromATM(int amount);
    // void depositToATM(int amount);
};

#endif