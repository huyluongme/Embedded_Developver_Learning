#include "atm_service.h"
#include "atm_exceptions.h"

ATMService::ATMService(int atm_balance) {
    m_atm = new ATM(atm_balance);
}

ATMService::~ATMService() {
    delete m_atm;
}

int ATMService::checkATMBalanceService() {
    // std::lock_guard<std::mutex> lock(atm_service_lock);
    return m_atm->getATMBalance();
}

int ATMService::checkUserBalanceService(User* user) {
    // std::lock_guard<std::mutex> lock(atm_service_lock);
    return user->getUserBalance();
}

void ATMService::withdrawService(User* user, int amount) {
    // std::lock_guard<std::mutex> lock(atm_service_lock);
    if(amount > user->getUserBalance()) {
        throw UserInsufficientFundsException();
    }
    
    if(amount > m_atm->getATMBalance()) {
        throw ATMInsufficientFundsException();
    }

    m_atm->setATMBalance(m_atm->getATMBalance() - amount);
    user->setUserBalance(user->getUserBalance() - amount);
}

void ATMService::depositService(User* user, int amount) {
    // std::lock_guard<std::mutex> lock(atm_service_lock);
    m_atm->setATMBalance(m_atm->getATMBalance() + amount);
    user->setUserBalance(user->getUserBalance() + amount);
}