#ifndef ATM_SERVICE_H
#define ATM_SERVICE_H

#include "atm.h"
#include "user.h"
#include <mutex>

class ATMService
{
private:
    ATM* m_atm;
public:
    ATMService(int atm_balance);
    ~ATMService();

    int     checkATMBalanceService();
    int     checkUserBalanceService(User* user);
    void    withdrawService(User* user, int amount);
    void    depositService(User* user, int amount);
};

#endif