#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <atomic>
#include <random>

#include "shared_variable.h"
#include "user.h"
#include "atm_app.h"

std::random_device rd;
std::mt19937 gen(rd()); // Khởi tạo với seed từ random_device
std::vector<User*> users;
ATMApp atm_app;

int intRand(const int & min, const int & max) {
    std::uniform_int_distribution<> range(min, max);
    return range(gen);
}

void initUsers(int user_num) {
    for(int i = 1; i <= user_num; i++)
        users.emplace_back(new User("User " + std::to_string(i), intRand(50, 5000)));

    std::cout << "List of user:\n";
    for(auto* user : users)
        std::cout << user->getUserName() << " with balance: " << user->getUserBalance() << '\n';
    std::cout << '\n';
}

void simulatorUseATM(User* user) {
    // printf("feature: %d\n", feature);
    //  int feature = feature_dis(gen); // Lấy số ngẫu nhiên từ 0 đến 2
    // printf("feature: %d\n", intRand(0, 2));
    atm_app.useATM(user, (ATMFeature)intRand(0, 2), intRand(50, 1000));
}

int main()
{
    gen.seed(std::chrono::system_clock::now().time_since_epoch().count());
    initUsers(users_num);
    atm_app.start(atm_balance, max_users);
    
    atm_app.checkATMBalanceFeature();
    
    std::vector<std::thread> threads;
    for(int i = 0; i < task_num; i++)
        threads.emplace_back(simulatorUseATM, users[intRand(0, users_num)]);

    for(auto& t : threads)
        t.join();

    // atm_app.checkATMBalanceFeature();
    
    // This program will create some sequence of random 
    // numbers on every program run within range lb to ub 
    
    return 0;
}