#include "user.h"

User::User(std::string name, int balance)
    : m_name(name), m_balance(balance) {}

User::~User() {}

std::string User::getUserName() {
    return m_name;
}

int User::getUserBalance() {
    std::lock_guard<std::mutex> lock(m_user_lock);
    return m_balance;
}

void User::setUserBalance(int new_balance) {
    std::lock_guard<std::mutex> lock(m_user_lock);
    m_balance = new_balance;
}