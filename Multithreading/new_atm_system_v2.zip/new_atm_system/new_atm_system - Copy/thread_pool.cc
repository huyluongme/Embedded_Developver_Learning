#include "thread_pool.h"
#include "shared_variable.h"

// std::mutex g_cout_lock;

ThreadPool::ThreadPool(int thread_num) : m_terminal(false), m_thread_id_cnt(0) {
    for(int i = 1; i <= thread_num; i++) {
        m_threads.emplace_back(&ThreadPool::threadFunction, this);
    }
    std::this_thread::sleep_for(std::chrono::seconds(2));
}

ThreadPool::~ThreadPool() {
    {
    std::unique_lock<std::mutex> lock(m_queue_lock);
    m_terminal = true;
    }
    m_cv.notify_all();
    for(auto& t : m_threads) {
        t.join();
    }
    m_threads.clear();
}


void ThreadPool::threadFunction() {
    {
        std::lock_guard<std::mutex> lock(g_cout_lock);
        m_thread_id_map[std::this_thread::get_id()] = ++m_thread_id_cnt;
        std::cout << "Thread [" << std::this_thread::get_id() << "] is created with simple id: " << m_thread_id_cnt;
        std::cout << "\n";
    }
    while(true) {
        std::function<void()> task;
        {
            std::unique_lock<std::mutex> lock(m_queue_lock);
            m_cv.wait(lock, [this]() {return m_terminal || !m_queue_task.empty();});
            if(m_terminal && m_queue_task.empty())
                return;
            task = std::move(m_queue_task.front());
            m_queue_task.pop();
        }
        task();
    }
}

void ThreadPool::enQueueTask(std::function<void()>& task) {
    {
        std::unique_lock<std::mutex> lock(m_queue_lock);
        m_queue_task.emplace(task);
    }
}

std::map<std::thread::id, int> ThreadPool::getThreadIDMap() {
    
    return m_thread_id_map;
}