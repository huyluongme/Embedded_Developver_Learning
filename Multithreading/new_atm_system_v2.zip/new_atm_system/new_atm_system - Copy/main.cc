#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <atomic>

#include "shared_variable.h"
#include "user_account.h"
#include "atm_app.h"
#include "thread_pool.h"

std::mutex g_cout_lock;
std::vector<UserAccount*> users;
ATMApp atm_app;
ThreadPool pool(thread_num);

void initUsers(int user_num) {
    for(int i = 1; i <= user_num; i++)
        users.emplace_back(new UserAccount("User " + std::to_string(i), (rand() % (5000 - 50 + 1))));

    std::cout << "List of user:\n";
    for(auto* user : users)
        std::cout << user->getUserName() << " with balance: " << user->getUserBalance() << '\n';
    std::cout << '\n';
}

void simulatorUseATM(UserAccount* user) {
    ATMFeature feature = ATMFeature(rand() % 3);
    std::function<void()> task;
    task = std::bind(&ATMApp::useATM, &atm_app, user, feature, (rand() % (1000 - 50 + 1)), pool.getThreadIDMap());
    pool.enQueueTask(task);
}

int main()
{
    srand(time(0));
    initUsers(users_num);
    atm_app.start(atm_balance, max_users);
    
    atm_app.checkATMBalanceFeature();
    for(int i = 0; i < task_num; i++)
        simulatorUseATM(users[(rand() % (19-0+1))]);


    return 0;
}