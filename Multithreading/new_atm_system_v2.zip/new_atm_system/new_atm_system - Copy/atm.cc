#include <thread>
#include "atm.h"
#include "shared_variable.h"

ATM::ATM(int atm_balance) : m_atm_balance(atm_balance) {}

ATM::~ATM() {}

int ATM::getATMBalance() {
    // std::lock_guard<std::mutex> lock(m_atm_lock);
    std::this_thread::sleep_for(std::chrono::milliseconds(sleep_milisecond));
    return m_atm_balance;
}

void ATM::setATMBalance(int new_balance) {
    std::this_thread::sleep_for(std::chrono::milliseconds(sleep_milisecond));
    this->m_atm_balance = new_balance;
}

// void ATM::withdrawFromATM(int amount) {
//     // std::lock_guard<std::mutex> lock(atm_balance_lock);
//     // std::this_thread::sleep_for(std::chrono::seconds(2));
//     m_atm_balance -= amount;
// }

// void ATM::depositToATM(int amount) {
//     // std::lock_guard<std::mutex> lock(atm_balance_lock);
//     // std::this_thread::sleep_for(std::chrono::seconds(2));
//     m_atm_balance += amount;
// }