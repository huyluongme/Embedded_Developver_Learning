#ifndef ATM_APP_H
#define ATM_APP_H

#include "atm_service.h"
#include "semaphore.h"
#include "thread_pool.h"

#define RESET "\033[0m"
#define BOLD "\033[1m"
#define RED "\033[91m"
#define GREEN "\033[92m"
#define YELLOW "\033[93m"
#define BLUE "\033[94m"

enum ATMFeature {
    CHECK_BALANCE,
    WITHDRAW,
    DIPOSIT,
};

class ATMApp
{
private:
    std::mutex m_atm_lock;
    ATMService* m_atm_services;
    Semaphore* m_sem;
public:
    ATMApp();
    ~ATMApp();

    void start(int atm_balance, int max_users);
    void checkATMBalanceFeature();
    void checkUserBalanceFeature(UserAccount* user);
    void withdrawFeature(UserAccount* user, int amount);
    void depositFeature(UserAccount* user, int amount);
    void useATM(UserAccount* user, ATMFeature feature, int amount, std::map<std::thread::id, int> thread_ip_map);

};

#endif