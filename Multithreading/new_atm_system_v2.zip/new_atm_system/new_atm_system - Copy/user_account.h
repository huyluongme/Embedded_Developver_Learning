#ifndef USER_ACCOUNT_H
#define USER_ACCOUNT_H

#include <iostream>
#include <string>

class UserAccount
{
private:
    std::string m_name;
    int m_balance;
    
public:
    UserAccount(std::string name, int balance);
    ~UserAccount();

    std::string getUserName();
    int         getUserBalance();
    void        setUserBalance(int new_balance);
    // void        withdrawUser(int amount);
    // void        depositUser(int amount);
};

#endif