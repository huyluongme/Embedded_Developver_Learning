#ifndef THREAD_POOL_H
#define THREAD_POOL_H

#include <iostream>
#include <thread>
#include <functional>
#include <vector>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <map>

class ThreadPool
{
private:
    std::vector<std::thread> m_threads;
    std::queue<std::function<void()>> m_queue_task;
    std::mutex m_queue_lock;
    std::condition_variable m_cv;
    std::atomic_bool m_terminal;
    std::map<std::thread::id, int> m_thread_id_map;
    std::atomic<int> m_thread_id_cnt;
    void threadFunction();
    
public:
    ThreadPool(int thread_num);
    ~ThreadPool();
    void enQueueTask(std::function<void()>& task);
    bool getTerminal();
    std::map<std::thread::id, int> getThreadIDMap();
};

#endif