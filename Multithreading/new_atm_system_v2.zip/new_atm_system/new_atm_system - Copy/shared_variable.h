#ifndef SHARED_VARIABLE_H
#define SHARED_VARIABLE_H

#include <mutex>

extern std::mutex g_cout_lock;

extern int atm_balance;
extern int users_num;
extern int max_users;
extern int thread_num;
extern int sleep_milisecond;
extern int task_num;

#endif